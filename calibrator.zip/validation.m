%% Read the Image of Objects to Be Measured
imOrig = imread("reference.jpg");
magnification = 25;
% figure; imshow(imOrig, InitialMagnification = magnification);
% title("Input Image");

%% Undistort the Image
% Since the lens introduced little distortion, use 'full' output view to illustrate that
% the image was undistored. If we used the default 'same' option, it would be difficult
% to notice any difference when compared to the original image. Notice the small black borders.
[im, newIntrinsics] = undistortImage(imOrig, intrinsics, OutputView = "full");
% figure; imshow(im, InitialMagnification = magnification);
% title("Undistorted Image");


%% Map points in image to real cordinates

worldPoints = [5 0;10.5 0;15.5 0;0 5;5 5;10.5 5;15.5 5;21 5;0 10;5 10;10.5 10;15.5 10;
    21 10;0 14.5;5 14.5;10.5 14.5;15.5 14.5;21 14.5;0 20;5 20;10.5 20;15.5 20;21 20;0 25;
    5 25;10.5 25;15.5 25;21 25;5 29.7;10.5 29.7;15.5 29.7]*10;

controlPoints_img =[382 2250; 369 1638; 350 1071;960 2781; 953 2242; 938 1632; 930 1071;908 421;1512 2777;1505 2237;1499 1632;
    1492 1067;1492 423;2000 2777;2006 2231;2004 1625;2010 1069;2015 427;2607 2766;2614 2227;2618 1623;2624 1063;2646 434;
    3142 2759;3153 2220;3168 1621;3181 1065; 3213 438;3664 2227;3683 1623;3701 1073]; 

% Adjust the imagePoints so that they are expressed in the coordinate system
% used in the original image, before it was undistorted.  This adjustment
% makes it compatible with the cameraParameters object computed for the original image.
newOrigin = intrinsics.PrincipalPoint - newIntrinsics.PrincipalPoint;
imagePoints = controlPoints_img + newOrigin; % adds newOrigin to every row of imagePoints

% Compute extrinsic parameters of the camera.
camExtrinsics = estimateExtrinsics(imagePoints, worldPoints, intrinsics);

% Get the world coordinates of the corners            
worldPoints1 = img2world2d(imagePoints, camExtrinsics, intrinsics);

figure()
plot(worldPoints(:,1),worldPoints(:,2),"bx",'LineWidth',1.5,'MarkerSize',5);
hold on
plot(worldPoints1(:,1),worldPoints1(:,2),"ro",'LineWidth',1.5,'MarkerSize',5);
legend("Ground Truth","Estimates");
hold off
grid on

corr_coeff = corr2(worldPoints1(:,[1,2]),worldPoints);
